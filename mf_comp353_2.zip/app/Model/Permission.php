<?php 

class Permission extends AppModel
{
	var $belongsTo = array('Item');
} ?>