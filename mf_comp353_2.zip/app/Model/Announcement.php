<?php 
class Announcement extends AppModel {
	
	var $belongsTo = 'User';
}
?>